<h2>
  <span>
    <svg class="icon" aria-hidden="true">
      <use xlink:href="#icon-article-fill"></use>
    </svg>推荐文章
  </span>
</h2>

<div class="widget-box recommend-post">
  <?php
    $sticky_posts = get_option('sticky_posts');
    if ($sticky_posts) {
      $sticky_posts = get_posts(array(
        'post__in' => get_option('sticky_posts'), // 获取置顶文章
        'numberposts' => 10 // 限制获取的文章数量
      ));
      echo '<ul>';
      foreach ($sticky_posts as $post) {
        echo '<li>';
        echo '<p><a href="'.get_permalink($post->ID).'">'.$post->post_title.'</a></p>'; // 显示文章标题和链接
        echo '</li>';
      }
      echo '</ul>';
    } else {
      echo '<p>暂无推荐文章</p>';
    }
  ?>
</div>