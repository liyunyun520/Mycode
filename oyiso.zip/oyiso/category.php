<?=get_header()?>

<?=category_theme_color_sync()?>

<section class="archive-category post-category-cover">
  <div class="screen banner-reveal">
    <a class="info">
      <?php 
        $current_category = get_queried_object();
        $image_url = get_term_meta($cat, 'category_image', true); 
        $image_color = get_term_meta($cat, 'category_image_color', true);
        if ($image_color && isset($image_color['url'])) {
          $url = $image_color['url'];
        } else {
          $url = '';
        }
        $url = $url ? $url : ($image_url ? $image_url : category_default_cover());
      ?>
      <?php
        $pic = $url;
        echo lazy_load_pic($pic);
      ?>
      <div class="cate_info">
        <h2><?=$current_category->name?></h2>
        <p><?=$current_category->description ? $current_category->description : '此分类暂时没有描述'?></p>
      </div>
      <span>共<?=get_post_count($cat, 'category')?>篇</span>
    </a>
  </div>
</section>

<section class="post-category">
  <div class="screen">
  <div class="screen-title main-reveal">Post Category</div>
    <div class="cate main-reveal">
      <?php
        $categories = get_categories();
        if($categories) {
          $svg = '<svg class="icon" aria-hidden="true"><use xlink:href="#icon-folder-full"></use></svg>';
          // var_dump($cat);
          foreach ($categories as $category) {
            if($category->term_id == $cat) {
              $active = 'active';
            } else {
              $active = '';
            }
            ?>
              <a class="<?=$active?>" href="<?=get_category_link($category->term_id)?>"><?=$svg?><?=$category->name?><span><?=get_post_count($category->term_id, 'category')?></span></a>
            <?php
          }
        } else {
          echo notice('warning', '', "There are <b>no more categories</b> left.");
        }
        
      ?>
    </div>
  </div>
</section>

<section class="popular current-category">
  <div class="screen">
    <ul>
      <?php
        // 创建 current_category_post 实例
        $current_category_post = new WP_Query(
          array(
            'post_type' => 'post', // 文章类型
            // 'posts_per_page' => 6, // 每页显示的文章数量
            'paged' => get_query_var('paged', 1), // 当前页数
            'ignore_sticky_posts' => 1, // 排除置顶文章
            'cat' => $cat, // 指定当前分类的 ID
            'order' => 'DESC' // 降序排列
          )
        );
        
        // 循环
        $currentCover = 1;
        if ($current_category_post->have_posts()) :
        while ($current_category_post->have_posts()) : $current_category_post->the_post();

        // 获得分类
        $categories = get_the_category();
      ?>
        <li class="main-reveal">
          <a href="<?=the_permalink()?>">
            <div class="cover">
              <div class="box">
                <?php
                  $pic = the_cover_url('medium', $currentCover);
                  echo lazy_load_pic($pic); $currentCover++;
                ?>
              </div>
            </div>
            <div class="info">
              <div class="top">
                <div class="cate" <?=theme_color_sync(true) ? 'style="color:'.theme_color_sync(true).'"' : ''?>>
                  <?php
                    if ($categories) {
                      foreach ($categories as $category) {
                        echo '<span class="url" data-href="'.esc_url(get_category_link($category->term_id)).'">
                        <svg class="icon" aria-hidden="true"><use xlink:href="#icon-folder-full"></use></svg> '.esc_html($category->name).'</span>';
                      }
                    }
                  ?>
                </div>
                <div class="title"><?=get_the_title() ? the_title() : '无标题'?></div>
              </div>
              <div class="date"><?=get_the_date()?><span class="drop">·</span><?=get_post_views()?> Views</div>
            </div>
          </a>
        </li>
      <?php endwhile; else : ?>
        <style>
          main .popular ul {
            display: block;
          }
        </style>
        <?=notice('warning', '', "There are <b>no articles</b> under this category.")?>
      <?php endif; wp_reset_postdata();?>
    </ul>
    <?=the_pagination($current_category_post)?>
  </div>
</section>

<?=get_footer()?>