<?php

require_once get_template_directory().'/vendor/autoload.php';
use Upyun\Upyun;
use Upyun\Config;

// 主题设置ajax处理
function oyiso_options() {
  // 检查用户权限
  if (!current_user_can('administrator')) {
    wp_send_json_error('failed');

  } else {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      // 获取并清理表单数据
      // $options = array_map('sanitize_text_field', $_POST);
      $options = $_POST;
      // error_log(print_r($options, true));
      // return;
      $obj_theme_color = new stdClass();

      // 获取主题颜色
      $theme_color = get_option('oyiso_theme_color');

      // 更新选项
      foreach ($options as $name => $value) {
        // 清除钩子名称
        if ($name == 'action') continue;
        // error_log(print_r($name, true));
        // continue;

        // 处理选项
        if ($value == 'true' || $value == 'false') {
          $value = $value == 'true' ? true : false;
        }

        update_option($name, $value);

        // 处理主题色
        if ($name == 'oyiso_theme_colors') {
          // error_log($value);
          // error_log(print_r($value, true));
          update_option('oyiso_theme_colors', json_decode(stripslashes($options['oyiso_theme_colors'])));
        }

        // 处理自定义主题色
        if ($name == 'oyiso_theme_colors_custom') {
          update_option('oyiso_theme_colors_custom', json_decode(stripslashes($options['oyiso_theme_colors_custom'])));
          if (get_option('oyiso_theme_color') == 'custom') {
            update_option('oyiso_theme_colors', get_option('oyiso_theme_colors_custom'));
          }
        }

        // 处理颜色选项
        if ($name == 'oyiso_theme_color' && $value == 'custom') {
          update_option('oyiso_theme_colors', get_option('oyiso_theme_colors_custom'));
        }
      }
  
      // 发送成功响应
      wp_send_json_success('success');
    } else {
      wp_send_json_error('failed');
    }
  }
}
add_action('wp_ajax_oyiso_options', 'oyiso_options');


// 管理员头像ajax处理
function update_avatar() {
  // 检查用户权限
  if (!current_user_can('administrator')) {
    wp_send_json_error('failed');

  } else {
    if (isset($_POST['avatar_url'])) {
      $avatar_url = $_POST['avatar_url'];
      $user_id = get_current_user_id();
      update_user_meta($user_id, 'avatar_url', $avatar_url);

      if (!empty($avatar_url)) {
        echo 'success';
      } else {
        echo get_avatar_url($user_id);
      }
    } else {
      echo 'failed';
    }
  }
  wp_die();
}
add_action('wp_ajax_update_avatar', 'update_avatar');


// 更新主题
function oyiso_update() {
  if (!current_user_can('administrator')) {
    wp_send_json_error('failed');
  }
  if (isset($_POST['url']) && isset($_POST['version'])) {
    $url = $_POST['url'];
    $version = $_POST['version'];
    if ($version == wp_get_theme()->get('Version')) {
      wp_send_json_success('当前已是最新版本！');
    }
    $destination = get_theme_root().'/oyiso.zip';
    $res = file_put_contents($destination, fopen($url, 'r'));
    if ($res !== false) {
      $zip = new ZipArchive;
      $res = $zip->open($destination);
      if ($res === TRUE) {
        $zip->extractTo(get_theme_root().'/oyiso');
        $zip->close();
        wp_send_json_success('更新成功！请刷新页面或缓存！');
      } else {
        wp_send_json_error('在线更新失败，请<a href="'.$url.'">手动下载</a>！');
      }
    } else {
      wp_send_json_error('在线更新失败，请<a href="'.$url.'">手动下载</a>！');
    }
  }
}
add_action('wp_ajax_oyiso_update', 'oyiso_update');