<?php
/**
 * 主题后台菜单和设置页面
 * 
 * @package Oyiso
 * @since 1.0.0
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 添加主题选项菜单
 */
function add_theme_options_menu() {
    add_menu_page(
        'Oyiso主题设置',      // 页面标题
        'Oyiso主题设置',      // 菜单标题
        'manage_options',     // 权限
        'oyiso-theme-options', // 菜单slug
        'oyiso_option_admin', // 回调函数
        'dashicons-admin-generic', // 图标
        60                    // 位置
    );
}
add_action('admin_menu', 'add_theme_options_menu');

/**
 * 主题设置页面回调
 */
function oyiso_option_admin() {
    if (!current_user_can('manage_options')) {
        wp_die('您没有权限访问此页面');
    }
    
    // 加载主题设置页面
    require_once get_template_directory() . '/admin/option.php';
}
