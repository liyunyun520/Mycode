<div class="item">
  <div class="field">
    <div class="title">
      <span>文章封面图</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_post_cover" value="<?=get_option('oyiso_post_cover')?>">
    </div>
  </div>
  <p class="tip">用户自定义默认文章封面图（支持随机图API），默认：<code>/assets/images/cover-post.jpg</code></p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>片刻封面图</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_moment_cover" value="<?=get_option('oyiso_moment_cover')?>">
    </div>
  </div>
  <p class="tip">用户自定义片刻页面封面图（支持随机图API），默认：<code>/assets/images/cover-post.jpg</code></p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>片刻个人描述</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_moment_desc" value="<?=get_option('oyiso_moment_desc')?>">
    </div>
  </div>
  <p class="tip">默认：<code><?=get_userdata(1) -> description ? get_userdata(1) -> description : '无'?></code></p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>片刻提示语</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput" id="oyiso_moment_prompt" name="oyiso_moment_prompt" <?=get_option('oyiso_moment_prompt') ? 'checked' : ''?>>
      <label for="oyiso_moment_prompt" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">显示在封面图下方</p>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>片刻提示语 - 标题</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_moment_prompt_title" value="<?=get_option('oyiso_moment_prompt_title')?>">
      </div>
    </div>
    <p class="tip">默认：<code>片刻与瞬间</code></p>
  </div>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>片刻提示语 - 描述</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_moment_prompt_excerpt" value="<?=get_option('oyiso_moment_prompt_excerpt')?>">
      </div>
    </div>
    <p class="tip">默认：<code>是一种短暂的时间，是一种短暂的美好，是一种短暂的记忆。</code></p>
  </div>
</div>