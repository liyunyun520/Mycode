<div class="item">
  <div class="field">
    <div class="title">
      <span>隐私模式</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_private" name="oyiso_private" <?=get_option('oyiso_private') ? 'checked' : ''?>>
      <label for="oyiso_private" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后仅登录用户可查看站点（不影响登录）</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>禁止缩略图</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_ban_thumbnail" name="oyiso_ban_thumbnail" <?=get_option('oyiso_ban_thumbnail') ? 'checked' : ''?>>
      <label for="oyiso_ban_thumbnail" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后媒体库上传文件只生成主图</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>又拍云存储</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_upyun_uss" name="oyiso_upyun_uss" <?=get_option('oyiso_upyun_uss') ? 'checked' : ''?>>
      <label for="oyiso_upyun_uss" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后媒体库使用云存储</p>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>服务名称</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_upyun_bucketname" value="<?=get_option('oyiso_upyun_bucketname')?>">
      </div>
    </div>
    <p class="tip">填写云存储服务名称（当前使用量：<span id="upyun-usage">未知</span> ）</p>

    <div class="field">
      <div class="title">
        <span>加速域名</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_upyun_host" value="<?=get_option('oyiso_upyun_host')?>">
      </div>
    </div>
    <p class="tip">格式：<code>http(s)://{自定义加速域名}</code>，如下</p>
    <ul class="tip">
      <li><code>http(s)://upyun.oyiso.cn</code></li>
      <li><code>http(s)://upyun.oyiso.cn/path</code></li>
    </ul>
    <p class="tip">请使用自定义绑定的域名，又拍云自带的域名仅用于开发测试使用</p>

    <div class="field">
      <div class="title">
        <span>操作员用户名</span>
      </div>
      <div class="text">
        <input type="password" name="oyiso_upyun_username" value="<?=get_option('oyiso_upyun_username')?>">
      </div>
    </div>
    <p class="tip">填写操作员用户名</p>

    <div class="field">
      <div class="title">
        <span>操作员授权密码</span>
      </div>
      <div class="text">
        <input type="password" name="oyiso_upyun_passwd" value="<?=get_option('oyiso_upyun_passwd')?>">
      </div>
    </div>
    <p class="tip">填写授权操作员的密码</p>
  </div>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>邮件SMTP配置</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_smtp" name="oyiso_smtp" <?=get_option('oyiso_smtp') ? 'checked' : ''?>>
      <label for="oyiso_smtp" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">使用自定义的邮箱发送邮件</p>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>SMTP服务器地址</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_smtp_host" value="<?=get_option('oyiso_smtp_host')?>">
      </div>
    </div>
    <p class="tip">填写SMTP服务器地址，如QQ的SMTP服务器地址 <code>smtp.qq.com</code></p>

    <div class="field">
      <div class="title">
        <span>SMTP服务器端口</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_smtp_port" value="<?=get_option('oyiso_smtp_port')?>">
      </div>
    </div>
    <p class="tip">填写SMTP服务器端口，如 <code>465</code>、<code>587</code>、<code>25</code>， QQ邮箱通常是 <code>465</code> 或 <code>25</code></p>

    <div class="field">
      <div class="title">
        <span>SMTP用户名</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_smtp_username" value="<?=get_option('oyiso_smtp_username')?>">
      </div>
    </div>
    <p class="tip">通常是你的邮箱地址，如 <code>user@example.com</code></p>

    <div class="field">
      <div class="title">
        <span>SMTP密码</span>
      </div>
      <div class="text">
        <input type="password" name="oyiso_smtp_password" value="<?=get_option('oyiso_smtp_password')?>">
      </div>
    </div>
    <p class="tip">填写你的SMTP配置密码，QQ邮箱为密钥</p>

    <div class="field">
      <div class="title">
        <span>SMTP加密方式</span>
      </div>
      <div class="text">
        <div class="select">
          <input type="hidden" name="oyiso_smtp_secure" value="<?=get_option('oyiso_smtp_secure') ? get_option('oyiso_smtp_secure') : ''?>">
          <input type="text" class="hide" placeholder="请选择加密方式" readonly autocomplete="off"> 
          <div class="ul-box">
            <ul>
              <li data-value=''>请选择加密方式</li>
              <li data-value='ssl'>SSL加密</li>
              <li data-value='tls'>TLS加密</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <p class="tip">选择一个加密方式，一般为 <code>SSL</code> 加密方式</p>

    <div class="field">
      <div class="title">
        <span>站点名称</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_smtp_sitename" value="<?=get_option('oyiso_smtp_sitename')?>">
      </div>
    </div>
    <p class="tip">填写自定义站点名称，默认：<code><?=get_bloginfo('name')?></code></p>

    <div class="field">
      <div class="title">
        <span>发件人名称</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_smtp_fromname" value="<?=get_option('oyiso_smtp_fromname')?>">
      </div>
    </div>
    <p class="tip">填写自定义发件人昵称，默认：<code><?php $display_name = get_userdata(1)->display_name; echo $display_name ? $display_name : get_bloginfo('name')?></code></p>
  </div>
</div>