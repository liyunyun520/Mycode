<div class="item">
  <div class="field">
    <div class="title">
      <span>导航栏动画</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_navbar_animation" name="oyiso_navbar_animation" <?=get_option('oyiso_navbar_animation') ? 'checked' : ''?>>
      <label for="oyiso_navbar_animation" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后导航栏有从上向下出现的动画</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>图片懒加载</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_lazyload" name="oyiso_lazyload" <?=get_option('oyiso_lazyload') ? 'checked' : ''?>>
      <label for="oyiso_lazyload" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后图片会在加载完成前显示加载图</p>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>预设加载图</span>
      </div>
      <div class="text">
        <div class="select">
          <input type="hidden" name="oyiso_lazyload_preset" value="<?=get_option('oyiso_lazyload_preset') ? get_option('oyiso_lazyload_preset') : '1'?>">
          <input type="text" class="hide" placeholder="预设加载图1 - 小电视" readonly autocomplete="off"> 
          <div class="ul-box">
            <ul>
              <li data-value='1'>预设加载图1 - 小电视</li>
              <li data-value='2'>预设加载图2 - 转圈的红色水滴</li>
              <li data-value='3'>预设加载图3 - 红色小书</li>
              <li data-value='4'>预设加载图4 - 可爱小猫</li>
              <li data-value='5'>预设加载图5 - 蓝色星环</li>
              <li data-value='6'>预设加载图6 - Dribbble篮球</li>
              <li data-value='7'>预设加载图7 - 五角星</li>
              <li data-value='8'>预设加载图8 - 千变万化的交通工具</li>
              <li data-value='9'>预设加载图9 - 转个不停</li>
              <li data-value='10'>预设加载图10 - 蓝色圆环</li>
              <li data-value='11'>预设加载图11 - 有趣的小羊羔</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <p class="tip">主题预设的加载图</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>自定义加载图</span>
        </div>
        <div class="text">
          <input type="text" name="oyiso_lazyload_custom" value="<?=get_option('oyiso_lazyload_custom')?>">
        </div>
      </div>
      <p class="tip">填写加载图URL，优先显示自定义加载图</p>
    </div>
  </div>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>友链自助申请</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_friend_sup" name="oyiso_friend_sup" <?=get_option('oyiso_friend_sup') ? 'checked' : ''?>>
      <label for="oyiso_friend_sup" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后用户可在友链页面自助填写申请友情链接</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>页面平滑滚动</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_smoothscroll" name="oyiso_smoothscroll" <?=get_option('oyiso_smoothscroll') ? 'checked' : ''?>>
      <label for="oyiso_smoothscroll" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后页面滚动时有缓冲使其更加平滑（更耗性能）</p>
</div>