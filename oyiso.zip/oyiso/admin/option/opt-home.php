<div class="item">
  <div class="field">
    <div class="title">
      <span>公告</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_notice" name="oyiso_notice" <?=get_option('oyiso_notice') ? 'checked' : ''?>>
      <label for="oyiso_notice" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后可在首页Tab栏显示公告（默认首页模板仅支持弹窗显示）</p>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>公告弹窗 <i>New-1.5.2</i></span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput disabled"  id="oyiso_notice_popup" name="oyiso_notice_popup" <?=get_option('oyiso_notice_popup') ? 'checked' : ''?>>
        <label for="oyiso_notice_popup" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">是否需要弹窗显示公告（更新公告后会重新弹窗）</p>
  </div>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>公告内容</span>
      </div>
      <div class="text">
        <textarea rows="5" class="home" name="oyiso_notice_text"><?=stripslashes(get_option('oyiso_notice_text'))?></textarea>
      </div>
    </div>
    <p class="tip">填写需要显示的内容即可</p>
  </div>
</div>

<div class="item home-select">
  <div class="field">
    <div class="title">
      <span>首页模板</span>
    </div>
    <div class="text">
      <div class="select">
        <input type="hidden" name="oyiso_home_tpl" value="<?=get_option('oyiso_home_tpl') ? get_option('oyiso_home_tpl') : ''?>">
        <input type="text" class="hide" placeholder="首页模板（默认）" readonly autocomplete="off"> 
        <div class="ul-box">
          <ul>
            <li data-value=''>首页模板（默认）</li>
            <li data-value='home1'>首页模板1</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <p class="tip">选择一个模板作为首页</p>
</div>

<div class="item home">
  <div class="item">
    <div class="field">
      <div class="title">
        <span>首页小组件</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_widgets" name="oyiso_widgets" <?=get_option('oyiso_widgets') ? 'checked' : ''?>>
        <label for="oyiso_widgets" class="toggleSwitch"></label>
      </div>
    </div>
    <ul class="tip">
      <li>开启后在首页顶部显示小组件</li>
      <li>社交链接在 <code>外观 - 菜单</code> 里添加</li>
    </ul>

    <!-- 子项目 -->
    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>小组件内容</span>
        </div>
        <div class="text">
          <div class="select">
            <input type="hidden" name="oyiso_widgets_content" value="<?=get_option('oyiso_widgets_content') ? get_option('oyiso_widgets_content') : ''?>">
            <input type="text" class="hide" placeholder="推荐文章" readonly autocomplete="off"> 
            <div class="ul-box">
              <ul>
                <li data-value=''>推荐文章</li>
                <li data-value='comment'>最新评论</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <ul class="tip">
        <li>推荐文章：将文章设置为置顶即可，最多 <code>10</code> 篇</li>
        <li>最新评论：显示网站最新的评论，最多 <code>10</code> 条</li>
      </ul>
    </div>
  </div>
</div>

<div class="item home home1">
  <div class="item">
    <div class="field">
      <div class="title">
        <span>首页封面</span>
      </div>
      <div class="text">
        <textarea rows="2" class="home1" name="oyiso_home1_cover"><?=stripslashes(get_option('oyiso_home1_cover'))?></textarea>
      </div>
    </div>
    <p class="tip">填写封面图链接，用英文逗号<code>,</code>隔开，（支持回车，支持随机图API），默认：<code>/assets/images/cover-category.jpg</code></p>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>首页标语</span>
      </div>
      <div class="text">
        <textarea rows="2" class="home1" name="oyiso_home1_slogan"><?=stripslashes(get_option('oyiso_home1_slogan'))?></textarea>
      </div>
    </div>
    <p class="tip">标语，字体较大，如需要主题色则使用span标签包裹，如：<code>&lt;span&gt;Oyiso Theme&lt;/span&gt;</code></p>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>首页副标语</span>
      </div>
      <div class="text">
        <textarea rows="2" class="home1" name="oyiso_home1_slogan_sub"><?=stripslashes(get_option('oyiso_home1_slogan_sub'))?></textarea>
      </div>
    </div>
    <p class="tip">副标语，字体较小，如需要主题色则使用span标签包裹，如：<code>&lt;span&gt;Oyiso Theme&lt;/span&gt;</code></p>
  </div>
  
  <div class="item">
    <div class="field">
      <div class="title">
        <span>隐藏波浪动画</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_waves" name="oyiso_home1_waves" <?=get_option('oyiso_home1_waves') ? 'checked' : ''?>>
        <label for="oyiso_home1_waves" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后隐藏波浪动画，该动画用于衔接页面过渡作用（建议默认开启）</p>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 博主信息</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_bloger" name="oyiso_home1_bloger" <?=get_option('oyiso_home1_bloger') ? 'checked' : ''?>>
        <label for="oyiso_home1_bloger" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示博主信息</p>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 置顶</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_post" name="oyiso_home1_post" <?=get_option('oyiso_home1_post') ? 'checked' : ''?>>
        <label for="oyiso_home1_post" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示置顶的文章</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>Tab栏 / 置顶 / 数量</span>
        </div>
        <div class="text">
          <input type="number" name="oyiso_home1_post_num" value="<?=get_option('oyiso_home1_post_num')?>">
        </div>
      </div>
      <p class="tip">填写显示的数量，默认值：<code>6</code></p>
    </div>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 片刻</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_moment" name="oyiso_home1_moment" <?=get_option('oyiso_home1_moment') ? 'checked' : ''?>>
        <label for="oyiso_home1_moment" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示最新的片刻</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>Tab栏 / 片刻 / 数量</span>
        </div>
        <div class="text">
          <input type="number" name="oyiso_home1_moment_num" value="<?=get_option('oyiso_home1_moment_num')?>">
        </div>
      </div>
      <p class="tip">填写显示的数量，默认值：<code>6</code></p>
    </div>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 评论</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_comment" name="oyiso_home1_comment" <?=get_option('oyiso_home1_comment') ? 'checked' : ''?>>
        <label for="oyiso_home1_comment" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示最新的评论</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>Tab栏 / 评论 / 数量</span>
        </div>
        <div class="text">
          <input type="number" name="oyiso_home1_comment_num" value="<?=get_option('oyiso_home1_comment_num')?>">
        </div>
      </div>
      <p class="tip">填写显示的数量，默认值：<code>6</code></p>
    </div>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 友链</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_bookmark" name="oyiso_home1_bookmark" <?=get_option('oyiso_home1_bookmark') ? 'checked' : ''?>>
        <label for="oyiso_home1_bookmark" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示最新的友链</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>Tab栏 / 友链 / 数量</span>
        </div>
        <div class="text">
          <input type="number" name="oyiso_home1_bookmark_num" value="<?=get_option('oyiso_home1_bookmark_num')?>">
        </div>
      </div>
      <p class="tip">填写显示的数量，默认值：<code>6</code></p>
    </div>
  </div>

  <div class="item">
    <div class="field">
      <div class="title">
        <span>Tab栏 / 画展</span>
      </div>
      <div class="text">
        <input type="checkbox" class="checkboxInput"  id="oyiso_home1_gallery" name="oyiso_home1_gallery" <?=get_option('oyiso_home1_gallery') ? 'checked' : ''?>>
        <label for="oyiso_home1_gallery" class="toggleSwitch"></label>
      </div>
    </div>
    <p class="tip">开启后可在首页Tab栏显示最新的画展</p>

    <div class="item-sub">
      <div class="field">
        <div class="title">
          <span>Tab栏 / 画展 / 数量</span>
        </div>
        <div class="text">
          <input type="number" name="oyiso_home1_gallery_num" value="<?=get_option('oyiso_home1_gallery_num')?>">
        </div>
      </div>
      <p class="tip">填写显示的数量，默认值：<code>6</code></p>
    </div>
  </div>
</div>