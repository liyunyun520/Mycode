<div class="item">
  <div class="field">
    <div class="title">
      <span>版权年份</span>
    </div>
    <div class="text">
      <input type="number" name="oyiso_copyright" value="<?=get_option('oyiso_copyright')?>">
    </div>
  </div>
  <p class="tip">填写数字即可，默认：<code><?=date('Y')?></code></p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>ICP备案号</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_icp" value="<?=get_option('oyiso_icp')?>">
    </div>
  </div>
  <p class="tip">页脚显示ICP备案号</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>公网安备号</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_icp_gov" value="<?=get_option('oyiso_icp_gov')?>">
    </div>
  </div>
  <p class="tip">页脚显示公网安备号</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>网站运行时间</span>
    </div>
    <div class="text">
      <input type="text" name="oyiso_run_time" value="<?=get_option('oyiso_run_time')?>">
    </div>
  </div>
  <p class="tip">页脚显示运行时间，输入建站日期，如 <code>2024/01/01</code></p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>又拍云联盟</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput" id="oyiso_upyun" name="oyiso_upyun" <?=get_option('oyiso_upyun') ? 'checked' : ''?>>
      <label for="oyiso_upyun" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后页脚显示又拍云联盟链接</p>
</div>