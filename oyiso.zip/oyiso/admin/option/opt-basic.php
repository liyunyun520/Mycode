<?php
  $theme_color = get_option('oyiso_theme_color');

  $theme_colors = get_option('oyiso_theme_colors');

  $theme_colors_custom = get_option('oyiso_theme_colors_custom');

  $pri = '#8183ff';
  $sub = '#67c3d3';
  
  if ($theme_colors_custom) {
    $pri = $theme_colors_custom->pri;
    $sub = $theme_colors_custom->sub;
  }
?>

<div class="item">
  <div class="field color-select">
    <div class="title">
      <span>默认主题色</span>
    </div>
    <div class="color-wrap text">
      <div class="radio-list">
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="purple" value="" <?=$theme_color == '' ? 'checked' : ''?>>
          <label for="purple" data-color-pri="#8183ff" data-color-sub="#67c3d3"></label>
          <p>因蓝紫</p>
        </div>
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="green" value="green" <?=$theme_color == 'green' ? 'checked' : ''?>>
          <label for="green" data-color-pri="#7ea774" data-color-sub="#e7b172"></label>
          <p>秋叶绿</p>
        </div>
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="orange" value="orange" <?=$theme_color == 'orange' ? 'checked' : ''?>>
          <label for="orange" data-color-pri="#e88a23" data-color-sub="#cf4141"></label>
          <p>芒果橙</p>
        </div>
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="blue" value="blue" <?=$theme_color == 'blue' ? 'checked' : ''?>>
          <label for="blue" data-color-pri="#009cd4" data-color-sub="#84dfff"></label>
          <p>哔哩哔哩 - 蓝</p>
        </div>
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="pink" value="pink" <?=$theme_color == 'pink' ? 'checked' : ''?>>
          <label for="pink" data-color-pri="#ed667e" data-color-sub="#ffc0cb"></label>
          <p>哔哩哔哩 - 粉</p>
        </div>
        <div class="radio-item theme_color">
          <input type="radio" class="color" name="oyiso_theme_color" id="custom" value="custom" <?=$theme_color == 'custom' ? 'checked' : ''?>>
          <label for="custom" data-color-pri="<?=$pri?>" data-color-sub="<?=$sub?>"></label>
          <p>自定义</p>
        </div>
      </div>
    </div>
  </div>

  <div class="item-sub" id="custom-color-panel">
    <div class="field">
      <div class="title">
        <span>调色盘 <i>New-1.5.2</i></span>
      </div>
      <div class="text">
        <label for="custom_color_pri">
          <input type="color" class="color-pri" id="custom_color_pri" name="oyiso_custom_color_pri" value="<?=$pri?>">
        </label>
        <label for="custom_color_sub">
          <input type="color" class="color-sub" id="custom_color_sub" name="oyiso_custom_color_sub" value="<?=$sub?>">
        </label>
      </div>
    </div>
    <p class="tip">分别为主色调和副色调（不想要渐变色就设置一样的颜色）</p>
  </div>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>色彩同步空间</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_cover_color" name="oyiso_cover_color" <?=get_option('oyiso_cover_color') ? 'checked' : ''?>>
      <label for="oyiso_cover_color" class="toggleSwitch"></label>
    </div>
  </div>
  <ul class="tip">
    <li>开启后使其全站主题色彩与封面图色调保持同步</li>
    <li>没有识别到封面图或识别的颜色不明显时则使用默认主题色</li>
    <li>Tip：只有发布或更新文章时才会触发取色</li>
  </ul>

  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>自定义取色封面图</span>
      </div>
      <div class="text">
        <input type="text" name="oyiso_cover_color_url" value="<?=get_option('oyiso_cover_color_url')?>">
      </div>
    </div>
    <p class="tip">填写封面图链接，仅对文章和页面有效（支持随机图API，但会出现封面和颜色不同步，不推荐填写）</p>
  </div>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>社交链接教程</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_social" name="oyiso_social" <?=get_option('oyiso_social') ? 'checked' : ''?>>
      <label for="oyiso_social" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后可查看社交图标</p>

  <!-- 子项目 -->
  <div class="item-sub">
    <p class="tip"><b>社交图标使用方法：</b></p>
    <p class="tip">外观 - 菜单 - 显示选项（右上角），勾选 <code>CSS类</code> （其他为可选项）</p>
    <p class="tip">第一个图标支持添加文字，在图标后面添加 <code>span</code> 标签即可</p>
    <p class="tip">具体使用方法如下（添加一个自定义链接）：</p>
    <ul class="tip">
      <li>URL：<code>https://github.com/kannafay</code></li>
      <li>链接文字 / 导航标签：<code>&lt;i class="iconfont icon-github-fill"&gt;&lt;/i&gt;&lt;span&gt;My GitHub&lt;/span&gt;</code></li>
      <li>title属性：<code>GitHub</code>（可选项）</li>
      <li>CSS类：<code>github</code></li>
    </ul>
    <br>
    <p class="tip"><b>社交图标（共25个）：</b></p>
    <ul class="tip">
      <li><i class="iconfont icon-github-fill"></i> GitHub：<code>&lt;i class="iconfont icon-github-fill"&gt;&lt;/i&gt;</code> CSS类：<code>github</code></li>
      <li><i class="iconfont icon-gitee-fill"></i> Gitee：<code>&lt;i class="iconfont icon-gitee-fill"&gt;&lt;/i&gt;</code> CSS类：<code>gitee</code></li>
      <li><i class="iconfont icon-bilibili-fill"></i> 哔哩哔哩：<code>&lt;i class="iconfont icon-bilibili-fill"&gt;&lt;/i&gt;</code> CSS类：<code>bili</code>（粉色）/  <code>bili-b</code>（蓝色）</li>
      <li><i class="iconfont icon-qq-fill"></i> QQ：<code>&lt;i class="iconfont icon-qq-fill"&gt;&lt;/i&gt;</code> CSS类：<code>qq</code></li>
      <li><i class="iconfont icon-wechat-fill"></i> 微信：<code>&lt;i class="iconfont icon-wechat-fill"&gt;&lt;/i&gt;</code> CSS类：<code>wechat</code></li>
      <li><i class="iconfont icon-netease-fill"></i> 网易云音乐：<code>&lt;i class="iconfont icon-netease-fill"&gt;&lt;/i&gt;</code> CSS类：<code>netease</code></li>
      <li><i class="iconfont icon-weibo-fill"></i> 微博：<code>&lt;i class="iconfont icon-weibo-fill"&gt;&lt;/i&gt;</code> CSS类：<code>weibo</code></li>
      <li><i class="iconfont icon-douyin-fill"></i> 抖音：<code>&lt;i class="iconfont icon-douyin-fill"&gt;&lt;/i&gt;</code> CSS类：<code>douyin</code></li>
      <li><i class="iconfont icon-kuaishou-fill"></i> 快手：<code>&lt;i class="iconfont icon-kuaishou-fill"&gt;&lt;/i&gt;</code> CSS类：<code>kuaishou</code></li>
      <li><i class="iconfont icon-tieba-fill"></i> 百度贴吧：<code>&lt;i class="iconfont icon-tieba-fill"&gt;&lt;/i&gt;</code> CSS类：<code>tieba</code></li>
      <li><i class="iconfont icon-zhihu-fill"></i> 知乎：<code>&lt;i class="iconfont icon-zhihu-fill"&gt;&lt;/i&gt;</code> CSS类：<code>zhihu</code></li>
      <li><i class="iconfont icon-redbook-fill"></i> 小红书：<code>&lt;i class="iconfont icon-redbook-fill"&gt;&lt;/i&gt;</code> CSS类：<code>redbook</code></li>
      <li><i class="iconfont icon-jianshu-fill"></i> 简书：<code>&lt;i class="iconfont icon-jianshu-fill"&gt;&lt;/i&gt;</code> CSS类：<code>jianshu</code></li>
      <li><i class="iconfont icon-douban-fill"></i> 豆瓣：<code>&lt;i class="iconfont icon-douban-fill"&gt;&lt;/i&gt;</code> CSS类：<code>douban</code></li>
      <li><i class="iconfont icon-youtube-fill"></i> Youtube：<code>&lt;i class="iconfont icon-youtube-fill"&gt;&lt;/i&gt;</code> CSS类：<code>yb</code></li>
      <li><i class="iconfont icon-telegram-fill"></i> Telegram：<code>&lt;i class="iconfont icon-telegram-fill"&gt;&lt;/i&gt;</code> CSS类：<code>tg</code></li>
      <li><i class="iconfont icon-instagram-fill"></i> Instagram：<code>&lt;i class="iconfont icon-instagram-fill"&gt;&lt;/i&gt;</code> CSS类：<code>ins</code></li>
      <li><i class="iconfont icon-twitter-fill"></i> Twitter：<code>&lt;i class="iconfont icon-twitter-fill"&gt;&lt;/i&gt;</code> CSS类：<code>twitter</code></li>
      <li><i class="iconfont icon-facebook-box-fill"></i> Facebook：<code>&lt;i class="iconfont icon-facebook-box-fill"&gt;&lt;/i&gt;</code> CSS类：<code>fb</code></li>
      <li><i class="iconfont icon-linkedin-box-fill"></i> Linkedin：<code>&lt;i class="iconfont icon-linkedin-box-fill"&gt;&lt;/i&gt;</code> CSS类：<code>in</code></li>
      <li><i class="iconfont icon-twitch-fill"></i> Twitch：<code>&lt;i class="iconfont icon-twitch-fill"&gt;&lt;/i&gt;</code> CSS类：<code>twitch</code></li>
      <li><i class="iconfont icon-messenger-fill"></i> Messenger：<code>&lt;i class="iconfont icon-messenger-fill"&gt;&lt;/i&gt;</code> CSS类：<code>mess</code></li>
      <li><i class="iconfont icon-dribbble-fill"></i> Dribbble：<code>&lt;i class="iconfont icon-dribbble-fill"&gt;&lt;/i&gt;</code> CSS类：<code>dribbble</code></li>
      <li><i class="iconfont icon-at-fill"></i> Email：<code>&lt;i class="iconfont icon-at-fill"&gt;&lt;/i&gt;</code> CSS类：<code>email</code></li>
      <li><i class="iconfont icon-links-fill"></i> 自定义链接：<code>&lt;i class="iconfont icon-links-fill"&gt;&lt;/i&gt;</code> CSS类：<code>link</code></li>
    </ul>
  </div>
</div>