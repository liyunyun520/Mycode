<div class="item">
  <div class="field">
    <div class="title">
      <span>自定义CSS代码</span>
    </div>
    <div class="text">
      <textarea rows="7" class="custom-code" name="oyiso_custom_css"><?=stripslashes(get_option('oyiso_custom_css'))?></textarea>
    </div>
  </div>
  <p class="tip">位于&lt;/head&gt;之前，直接写样式代码，不用添加&lt;style&gt;标签。</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>自定义JavaScript代码</span>
    </div>
    <div class="text">
      <textarea rows="7" class="custom-code" name="oyiso_custom_js"><?=stripslashes(get_option('oyiso_custom_js'))?></textarea>
    </div>
  </div>
  <p class="tip">位于底部，直接填写JS代码，不需要添加&lt;script&gt;标签。</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>自定义HTML代码-头部</span>
    </div>
    <div class="text">
      <textarea rows="7" class="custom-code" name="oyiso_custom_html_head"><?=stripslashes(get_option('oyiso_custom_html_head'))?></textarea>
    </div>
  </div>
  <p class="tip">位于&lt;/head&gt;之前，这部分代码是在主要内容显示之前加载，通常是CSS样式、自定义的&lt;meta&gt;标签、全站头部JS等需要提前加载的代码，需填HTML标签。</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>自定义HTML代码-底部</span>
    </div>
    <div class="text">
      <textarea rows="7" class="custom-code" name="oyiso_custom_html_foot"><?=stripslashes(get_option('oyiso_custom_html_foot'))?></textarea>
    </div>
  </div>
  <p class="tip">位于&lt;/body&gt;之前，这部分代码是在主要内容加载完毕加载，通常是其他自定义内容或JS代码，需填HTML标签。</p>
</div>