<div class="item">
  <div class="field">
    <div class="title">
      <span>登录后评论</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_comments_login" name="oyiso_comments_login" <?=get_option('oyiso_comments_login') ? 'checked' : ''?>>
      <label for="oyiso_comments_login" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后用户必须登录后才可以发表评论</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>页面评论区</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_comments_page" name="oyiso_comments_page" <?=get_option('oyiso_comments_page') ? 'checked' : ''?>>
      <label for="oyiso_comments_page" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后页面可使用评论功能（页面默认关闭，需在页面编辑页单独开启评论功能）</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>文章评论区</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_comments_post" name="oyiso_comments_post" <?=get_option('oyiso_comments_post') ? 'checked' : ''?>>
      <label for="oyiso_comments_post" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后文章详情页可使用评论功能</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>片刻评论区</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_comments_moment" name="oyiso_comments_moment" <?=get_option('oyiso_comments_moment') ? 'checked' : ''?>>
      <label for="oyiso_comments_moment" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后片刻页面可使用评论功能</p>
</div>

<div class="item">
  <div class="field">
    <div class="title">
      <span>IP归属地</span>
    </div>
    <div class="text">
      <input type="checkbox" class="checkboxInput"  id="oyiso_comments_ip" name="oyiso_comments_ip" <?=get_option('oyiso_comments_ip') ? 'checked' : ''?>>
      <label for="oyiso_comments_ip" class="toggleSwitch"></label>
    </div>
  </div>
  <p class="tip">开启后可获取评论用户IP归属地</p>

  <!-- 子项目 -->
  <div class="item-sub">
    <div class="field">
      <div class="title">
        <span>IP归属地API</span>
      </div>
      <div class="text">
        <div class="select">
          <input type="hidden" name="oyiso_comments_ip_api" value="<?=get_option('oyiso_comments_ip_api') ? get_option('oyiso_comments_ip_api') : ''?>">
          <input type="text" class="hide" placeholder="请选择API接口" readonly autocomplete="off"> 
          <div class="ul-box">
            <ul>
              <li data-value=''>请选择API接口</li>
              <li data-value='tencent'>腾讯位置服务（国内）</li>
              <li data-value='baidu'>百度智能定位（国内）</li>
              <li data-value='ipinfo'>ipinfo.io（国外）</li>
              <li data-value='free'>免费API接口（全球）</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <p class="tip">选择一个API来获取用户IP归属地</p>
  </div>

  <!-- 子项目-子项目 -->
  <div class="select-sub">
    <div class="field">
      <div class="title">
        <span>IP归属地API密钥</span>
      </div>
      <div class="text">
        <input type="password" name="oyiso_comments_ip_api_key" value="<?=get_option('oyiso_comments_ip_api_key')?>">
      </div>
    </div>
    <ul class="tip">
      <li>腾讯API：选择 <code>WebServiceAPI</code> 填写 <code>Key</code> 即可（采用腾讯API+免费API方案）</li>
      <li>百度API：选择 <code>服务端</code> 填写 <code>AK</code> 即可（采用百度API+免费API方案）</li>
      <li>ipinfo.io：登录注册后填写 <code>token</code> 即可（可获取全球IP归属地）</li>
      <li>免费API：无需填写密钥，可获取全球IP归属地（获取速度慢，不稳定），推荐上面三选一</li>
    </ul>
  </div>
</div>