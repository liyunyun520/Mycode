<?php
/**
 * Oyiso Theme Functions
 * 
 * @package Oyiso
 * @version 1.5.2
 * @requires PHP 8.0+
 * @requires WordPress 5.0+
 * 
 * @author Oyiso
 * @email me@onll.cn
 * @created 2024-01-12
 * @updated 2024-12-04
 */

// 防止直接访问
if (!defined('ABSPATH')) {
    exit;
}

// PHP版本检查
if (version_compare(PHP_VERSION, '8.0.0', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p><strong>Oyiso主题错误：</strong>需要 PHP 8.0 或更高版本。当前版本：' . PHP_VERSION . '</p></div>';
    });
    return;
}

// 自定义静态资源路径
function file_uri() {
  return get_template_directory_uri();
}

// 引入主题功能模组
require_once get_template_directory().'/modules/add-email.php'; //邮件SMTP
require_once get_template_directory().'/modules/add-category-image.php'; //添加一个图片链接字段到分类中
require_once get_template_directory().'/modules/add-menu.php'; //添加导航菜单
require_once get_template_directory().'/modules/add-bookmark.php'; //添加友情链接
require_once get_template_directory().'/modules/add-moment.php'; //添加片刻瞬间
require_once get_template_directory().'/modules/add-gallery.php'; //添加画展
require_once get_template_directory().'/modules/add-comments.php'; //评论区
require_once get_template_directory().'/modules/add-shortcode.php'; //添加短代码
require_once get_template_directory().'/modules/get-post-image-color.php'; //获取文章特色图片主色调和副色调
require_once get_template_directory().'/modules/get-category-image-color.php'; //获取分类特色图片主色调和副色调
require_once get_template_directory().'/modules/get-post-views.php'; //设置文章浏览量
require_once get_template_directory().'/modules/get-comments.php'; //评论区
require_once get_template_directory().'/modules/get-user-location.php'; //获取用户地理位置
require_once get_template_directory().'/modules/get-user-avatar.php'; //用户头像
require_once get_template_directory().'/modules/get-home-newest.php'; // 首页获取最新内容
require_once get_template_directory().'/modules/upyun-uss.php'; //又拍云存储
require_once get_template_directory().'/modules/other.php'; //其他设置
require_once get_template_directory().'/admin/auth.php'; //主题设置菜单
require_once get_template_directory().'/admin/oyiso_options.php'; //主题设置AJAX处理

// 引入ajax请求模组
require_once get_template_directory().'/modules/ajax/get-theme-version.php'; //获取主题版本

// 引入插件
require_once 'plugins/external-media-without-import/external-media-without-import.php'; //添加媒体外链