<div class="comment-container" id="<?=get_the_ID()?>">
  <div class="comment-top">
    <h3>参与讨论</h3>
    <div class="close">
      <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-close-fill"></use>
      </svg>
    </div>
    <div class="close-tip">
      <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-arrow-down"></use>
      </svg><span>左滑关闭</span>
    </div>
  </div>
  <div class="comment-body">
    <div class="next-comments">
      <a>
        <svg class="icon" aria-hidden="true">
          <use xlink:href="#icon-loading"></use>
        </svg><span>加载更多</span>
      </a>
    </div>
    <ul></ul>
  </div>
  <div class="comment-response">
    <div class="emoji-box">
      <div class="emoji-content">
        <div class="tab">
          <ul>
            <li class="active">😀</li>
            <li>颜文字</li>
          </ul>
        </div>
        <div class="list">
          <ul>
            <li class="active"></li>
            <li></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="go-bottom">
      <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-arrow-down"></use>
      </svg><span>返回底部</span>
    </div>
    <?php
      $post_id = get_the_ID();
      $logged = is_user_logged_in();
      if ($logged) {
        $user_id = get_current_user_id(); //获取当前用户ID
        $user_avatar = get_avatar_url($user_id); //获取当前用户头像
        $user_info = get_userdata($user_id); //获取当前用户信息
        $user_name = $user_info -> display_name; //获取当前用户昵称
        $user_email = $user_info -> user_email; //获取当前用户邮箱
        $user_url = $user_info -> user_url; //获取当前用户URL
      } else {
        if(isset($_COOKIE['visitor_email'])) {
          $cookie_value = $_COOKIE["visitor_email"];
          $user_avatar = get_avatar_url($cookie_value);
        } else {
          $user_avatar = get_avatar_url(0);
        }
          //获取默认头像
        $user_name = '点击填写用户信息'; //获取默认昵称
        $user_email = ''; //获取默认邮箱
        $user_url = ''; //获取默认URL
      }
      
      if (get_option('oyiso_comments_login') && !$logged) {
        $login_to_comment = true;
        $user_name = '请登录后发表评论';
      } else {
        $login_to_comment = false;
      }

      
    ?>
    <form class="commentForm">
      <?php
        if (!$logged && !$login_to_comment) {
          ?>
          <div class="visitor">
            <div class="basic-info">
              <input type="text" name="author" value="" placeholder="昵称*" maxlength="245" require>
              <input type="text" name="email" value="" placeholder="邮箱*" maxlength="100" require>
              <input type="text" name="url" value="" placeholder="网站 (http:// 或 https://)" maxlength="200">

              <label class="comment-cookies">
                <input type="checkbox">
                <svg viewBox="0 0 64 64" height="1em" width="1em">
                  <path d="M 0 16 V 56 A 8 8 90 0 0 8 64 H 56 A 8 8 90 0 0 64 56 V 8 A 8 8 90 0 0 56 0 H 8 A 8 8 90 0 0 0 8 V 16 L 32 48 L 64 16 V 8 A 8 8 90 0 0 56 0 H 8 A 8 8 90 0 0 0 8 V 56 A 8 8 90 0 0 8 64 H 56 A 8 8 90 0 0 64 56 V 16" pathLength="575.0541381835938" class="path"></path>
                </svg><span>勾选保存信息</span>
              </label>
            </div>
          </div>
          <?php
        }
      ?>
      <div class="textarea">
        <textarea name="comment" id="comment" placeholder="我想说两句..." maxlength="500"></textarea>
      </div>
      <div class="form-tool">
        <div class="reply">
          <button type="button" class="cancel"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-danger-full"></use></svg><span>取消回复</span></button>
          <button type="button" class="emoji"><svg class="icon" aria-hidden="true"><use xlink:href="#icon-user-smile-fill"></use></svg><span>Emoji</span></button>
          <button type="submit" class="send" disabled><svg class="icon" aria-hidden="true"><use xlink:href="#icon-send-tg-fill"></use></svg><span>发送</span></button>
        </div>
        <?php
          if ($logged) {
            ?>
              <div class="user-info">
                <div class="avatar">
                  <img src="<?=$user_avatar?>" alt="">
                </div>
                <div class="name"><?=$user_name?></div>
              </div>
            <?php
          } else {
            ?>
              <a <?=$login_to_comment ? 'href="'.wp_login_url(home_url(add_query_arg(array()))).'" target="_blank"' : ''?> class="user-info no-login">
                <div class="avatar">
                  <img src="<?=$user_avatar?>" alt="">
                </div>
                <div class="name"><?=$user_name?></div>
              </a>
            <?php
          }
        ?>
      </div>
      <div class="comment_info_hidden">
        <input type="hidden" name="comment_post_ID" value="<?=$post_id?>">
        <input type="hidden" name="comment_parent" value="0">
        <?php
          if($logged) {
            echo '<input type="hidden" name="author" value="'.$user_name.'">';
            echo '<input type="hidden" name="email" value="'.$user_email.'">';
            echo '<input type="hidden" name="url" value="'.$user_url.'">';
          }
        ?>
      </div>
    </form>
  </div>
</div>