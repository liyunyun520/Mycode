<?php
if (!defined('ABSPATH')) {
  exit;
}

// 网站标题
function show_wp_title() {
  global $page, $paged;
  wp_title('&#8211;', true, 'right');
  bloginfo('name');
  $site_description = get_bloginfo( 'description', 'display' );
  if($site_description && (is_home() || is_front_page()))
  echo ' &#8211; '.$site_description;
  if ( $paged >= 2 || $page >= 2 )
  echo ' &#8211; '.sprintf('第%s页', max($paged, $page));
}


// 阅读时间（优化版：减少循环次数）
add_action('save_post', 'reading_time');
function reading_time(int $post_id): void {
  // 获取文章内容
  $content = get_post_field('post_content', $post_id);
  if (empty($content)) {
    update_post_meta($post_id, 'reading_time', '');
    return;
  }

  // 移除 HTML 标签和多余空格
  $string = preg_replace('/\s+/u', '', strip_tags($content));
  if (empty($string)) {
    update_post_meta($post_id, 'reading_time', '');
    return;
  }

  // 统计中文字符（包括全角符号）
  $chinese_count = preg_match_all('/[\x{4e00}-\x{9fa5}\x{3000}-\x{303f}\x{ff01}-\x{ff5e}]/u', $string);
  
  // 统计英文字符
  $english_count = preg_match_all('/[a-zA-Z]/', $string);
  
  // 总字数：中文算1个字，英文算0.5个字
  $word_count = $chinese_count + ($english_count * 0.5);
  
  // 计算阅读时间（每分钟300字）
  $reading_minutes = max(1, (int) ceil($word_count / 300));
  
  $reading_time = $reading_minutes === 1 ? '1 Min read' : $reading_minutes . ' Mins read';

  // 更新元数据
  update_post_meta($post_id, 'reading_time', $reading_time);
}


// 修正评论用户IP不准确问题
if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
  $list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
  $_SERVER['REMOTE_ADDR'] = $list[0];
}


// 禁止引号半角/全角切换
add_filter('run_wptexturize', '__return_false');


// 获取分类下的文章数量（优化版：使用缓存的计数）
function get_post_count($id, $taxonomy): int {
  // 使用 WordPress 内置函数获取分类文章数
  if ($taxonomy === 'category') {
    $term = get_term($id, 'category');
    if ($term && !is_wp_error($term)) {
      return $term->count;
    }
  }
  
  // 对于其他分类法，使用更高效的方式
  $cache_key = "post_count_{$taxonomy}_{$id}";
  $cached = wp_cache_get($cache_key, 'oyiso');
  
  if (false !== $cached) {
    return (int) $cached;
  }
  
  $args = array(
    'tax_query' => array(                     
      array(
        'taxonomy' => $taxonomy,
        'field' => 'id',
        'terms' => array($id),
        'include_children' => true,
      )
    ),
    'posts_per_page' => 1,
    'fields' => 'ids',
    'no_found_rows' => false,
  );
  $query = new WP_Query($args);
  $count = $query->found_posts;
  
  // 缓存结果 5 分钟
  wp_cache_set($cache_key, $count, 'oyiso', 300);
  
  return $count;
}


// primary/success/danger/warning/info
function notice(string $status, string $icon, string $text) {
  if(!empty($icon)) {
    return "
      <div class='notice {$status} main-reveal'>
        <svg class='icon' aria-hidden='true'>
          <use xlink:href='#{$icon}'></use>
        </svg>
        <p>{$text}</p>
      </div>
    ";
  } else {
    return "
      <div class='notice {$status} main-reveal'>
        <svg class='icon' aria-hidden='true'>
          <use xlink:href='#icon-{$status}-full'></use>
        </svg>
        <p>{$text}</p>
      </div>
    ";
  }
}


// 分页
function the_pagination($wp_query) {
  $pagination = paginate_links(array(
    'total' => $wp_query->max_num_pages, // 当前查询的最多页
    'prev_text' => '上一页', // 上一页链接文本
    'next_text' => '下一页', // 下一页链接文本
    'mid_size' => 2, // 当前页码两边显示的页码数量
    'end_size' => 1, // 开始和结束页码显示的数量
    'type' => 'array', // 输出列表形式的分页链接
    'before_page_number' => '<span class="page-number">', // 页码前的 HTML
    'after_page_number' => '</span>' // 页码后的 HTML
  ));
  if(!empty($pagination)) {
    echo '<div class="pagination main-reveal">';
    foreach ($pagination as $page_link) {
      echo $page_link;
    }
    echo '</div>';
  }
}


//搜索时排除页面
// add_filter('register_post_type_args', function($args, $post_type){
//   if($post_type == 'page'){
//     $args['exclude_from_search']  = true;
//   }
//   return $args;
// }, 10, 2);


// 添加后台自定义样式
function custom_admin_style() {
  // 确保我们在后台页面上
  if (is_admin()) {
    wp_enqueue_style('admin-css', file_uri().'/assets/css/admin.css');
    wp_enqueue_script('marked-js', file_uri().'/assets/js/marked.min.js');
    wp_enqueue_script('editer-js', file_uri().'/assets/js/admin.js');
  }
}
add_action('admin_enqueue_scripts', 'custom_admin_style');


// 隐私模式
function private_mode() {
  if (!current_user_can('administrator') && !is_login()) {
    wp_redirect(wp_login_url(), 302);
  }
}
if(get_option('oyiso_private')) {
  private_mode();
}


// 输出markdown
function oyiso_md($content) {
  $Parsedown = new Parsedown();
  return $Parsedown->text($content);
}


// 编辑器过滤
function oyiso_set_default_editor() {
  $screen = get_current_screen();
  if (($screen -> post_type) == 'gallery') {
    return 'html'; // html 是文本模式，tinymce 是可视化模式
  }
}
add_filter('wp_default_editor', 'oyiso_set_default_editor');


// xx少天前（优化版）
function get_days_ago(string $date, bool $daysago = true): string {
  $timestamp = strtotime($date);
  if ($timestamp === false) {
    return '';
  }
  
  if (!$daysago) {
    return date('Y-m-d H:i', $timestamp);
  }
  
  $diff = time() - $timestamp;
  
  // 使用匹配更高效
  return match (true) {
    $diff < 60 => '刚刚',
    $diff < 3600 => floor($diff / 60) . '分钟前',
    $diff < 86400 => floor($diff / 3600) . '小时前',
    $diff < 2592000 => floor($diff / 86400) . '天前',
    $diff < 31536000 => floor($diff / 2592000) . '个月前',
    default => floor($diff / 31536000) . '年前',
  };
}


// 懒加载图片（优化版：缓存选项）
function lazy_load(): ?string {
  static $lazyload_url = null;
  
  if ($lazyload_url !== null) {
    return $lazyload_url;
  }
  
  if (!get_option('oyiso_lazyload')) {
    $lazyload_url = null;
    return null;
  }
  
  $custom_url = get_option('oyiso_lazyload_custom');
  if (!empty($custom_url)) {
    $lazyload_url = $custom_url;
    return $lazyload_url;
  }
  
  $preset = get_option('oyiso_lazyload_preset') ?: '1';
  $lazyload_url = file_uri() . '/assets/images/loading/loading' . $preset . '.gif';
  
  return $lazyload_url;
}

// 输出图片（优化版：减少重复调用）
function lazy_load_pic(string $pic, string $reveal = ''): string {
  $lazy_pic = lazy_load();
  
  if ($lazy_pic) {
    $class_attr = $reveal ? ' class="' . esc_attr($reveal) . '"' : '';
    return '<img lazyload data-src="' . esc_url($pic) . '" src="' . esc_url($lazy_pic) . '" alt=""' . $class_attr . '>';
  }
  
  $class_attr = $reveal ? ' class="' . esc_attr($reveal) . '"' : '';
  return '<img src="' . esc_url($pic) . '" alt=""' . $class_attr . '>';
}


// home1随机输出图片
function home1_random_img() {
  $imgs = str_replace(array(' ', "\r", "\n"), '', get_option('oyiso_home1_cover'));
  if ($imgs) {
    $imgs = array_filter(explode(',', $imgs));
    if (!empty($imgs)) {
      $random_img = $imgs[array_rand($imgs)];
      return $random_img;
    }
  }
}

// php替换标签（优化版：单次正则替换）
function replaceAToSpan(string $string): string {
  // 使用单次正则替换所有 a 标签
  $string = preg_replace('/<a[^>]*>/i', '<span>', $string);
  $string = preg_replace('/<\/a>/i', '</span>', $string);
  return $string;
}

// 查找某个类型的文章在第几页（优化版：使用 SQL 直接计算）
function get_moment_page($post_id): int {
  global $wpdb;
  
  // 获取目标文章的发布日期
  $target_post = get_post($post_id);
  if (!$target_post || $target_post->post_type !== 'moment') {
    return 1;
  }
  
  $posts_per_page = (int) get_option('posts_per_page', 10);
  if ($posts_per_page < 1) {
    $posts_per_page = 10;
  }
  
  // 使用 SQL 计算该文章之前有多少篇已发布的 moment
  $count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->posts} 
     WHERE post_type = 'moment' 
     AND post_status = 'publish' 
     AND post_date > %s",
    $target_post->post_date
  ));
  
  $position = (int) $count + 1;
  return (int) ceil($position / $posts_per_page);
}


