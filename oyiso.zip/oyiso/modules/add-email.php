<?php
if (!defined('ABSPATH')) {
  exit;
}

// 邮件SMTP
use PHPMailer\PHPMailer\PHPMailer;
require_once get_template_directory().'/vendor/autoload.php';
if (get_option('oyiso_smtp')) {
  add_action('phpmailer_init', 'custom_phpmailer_init');
  function custom_phpmailer_init(PHPMailer $phpmailer) {
    $host = get_option('oyiso_smtp_host');
    $port = get_option('oyiso_smtp_port');
    $username = get_option('oyiso_smtp_username');
    $password = get_option('oyiso_smtp_password');
    $secure = get_option('oyiso_smtp_secure');
    $smtp_fromname = get_option('oyiso_smtp_fromname');
    $display_name = get_userdata(1)->display_name;
    $fromname = $smtp_fromname ? $smtp_fromname : ($display_name ? $display_name : get_bloginfo('name'));
    if ($host && $port && $username && $password && $secure) {
      $phpmailer->isSMTP();     
      $phpmailer->Host = $host; // 你的 SMTP 服务器地址
      $phpmailer->SMTPAuth = true; 
      $phpmailer->Port = $port; 
      $phpmailer->Username = $username; // SMTP 用户名，通常是你的邮箱地址
      $phpmailer->Password = $password; // SMTP 密码
      $phpmailer->SMTPSecure = $secure; // 加密方式，可以是 'ssl' 或 'tls'
      $phpmailer->From = $username; // 发件人地址
      $phpmailer->FromName = $fromname; // 发件人名称
    }
  }
}


// 评论通知（评论、回复）
add_action('comment_post', 'oyiso_comment_post');
function oyiso_comment_post($comment_id) {
  $comment = get_comment($comment_id); // 评论对象
  $comment_content = $comment->comment_content; // 评论内容
  $parent_comment_id = $comment->comment_parent; // 父级评论 ID
  $comment_status = wp_get_comment_status($comment_id); // 评论状态
  $comment_author = $comment->comment_author; // 评论者昵称
  $comment_author_email = $comment->comment_author_email; // 评论者邮箱
  $post_id = $comment->comment_post_ID; // 文章 ID
  $post_name = get_the_title($post_id); // 文章标题
  $post_url = get_permalink($post_id); // 文章链接
  $post_type = get_post_type($post_id); // 文章类型
  $smtp_sitename = get_option('oyiso_smtp_sitename'); // 自定义网站名称
  $site_name = $smtp_sitename ? $smtp_sitename : get_bloginfo('name'); // 网站名称
  $site_url = get_bloginfo('url'); // 网站链接
  $admin_email = get_option('admin_email'); // 博主邮箱

  $theme_colors = get_option('oyiso_theme_colors');
  if (isset($theme_colors->pri) && !empty($theme_colors->pri)) {
    $theme_color_pri = $theme_colors->pri;
  } else {
    $theme_color_pri = '#8183ff';
  }

  $email_css = "style='background-color:#f5f5f5;padding:15px;border-left:3px solid {$theme_color_pri};'"; // 邮件样式
  $headers = array('Content-Type: text/html; charset=UTF-8'); // 邮件头部

  // 如果是回复评论
  if (!empty($parent_comment_id)) {
    $parent_comment = get_comment($parent_comment_id); // 父级评论对象
    $parent_comment_author = $parent_comment->comment_author; // 被回复者昵称
    $parent_comment_author_email = $parent_comment->comment_author_email; // 被回复者邮箱


    // 待审核发给博主
    if ($comment_status != 'approved') {
      $comment_approve_url = admin_url("comment.php?action=editcomment&c={$comment_id}");
      $pending = "<p>审核地址：<a href='{$comment_approve_url}'>{$comment_approve_url}</a></p>";
      $subject = "您的网站 [{$site_name}] 有了新的评论（待审核）";
      if ($parent_comment_author_email == $admin_email) {
        $who = '您';
      } else {
        $who = $parent_comment_author;
      }
      if ($post_type == 'post' || $post_type == 'page') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>{$who}</b>：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
          {$pending}
        ";
      } else if ($post_type == 'moment') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在片刻中回复了 <b>{$who}</b>：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      } else {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>{$who}</b>：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      }
      wp_mail($admin_email, $subject, $message, $headers);
      return;
    }

    // 如果发送者是博主，被回复者不是博主
    if ($comment_author_email == $admin_email) {
      if ($parent_comment_author_email != $admin_email) {
        // 发给被回复者（博主回复了xxx）
        $subject = "您在网站 [{$site_name}] 中的评论有了新的回复";
        if ($post_type == 'post' || $post_type == 'page') {
          $message = "
            <p><b>{$parent_comment_author}</b>，您好！</p>
            <p>博主 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
            <p {$email_css}>{$comment_content}</p>
            <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
          ";
        } else if ($post_type == 'moment') {
          $message = "
            <p><b>{$parent_comment_author}</b>，您好！</p>
            <p>博主 <b>{$comment_author}</b> 在片刻中回复了 <b>您</b> ：</p>
            <p {$email_css}>{$comment_content}</p>
            <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          ";
        } else {
          $message = "
            <p><b>{$parent_comment_author}</b>，您好！</p>
            <p>博主 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
            <p {$email_css}>{$comment_content}</p>
            <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          ";
        }
        wp_mail($parent_comment_author_email, $subject, $message, $headers);
        return;
      } else {
        return;
      }
    } 

    // 如果发送者不是博主，被回复者是博主
    if ($comment_author_email != $admin_email && $parent_comment_author_email == $admin_email) {
      // 发给博主 需审核
      // 如果是待批准状态
      if ($comment_status != 'approved') {
        $comment_approve_url = admin_url("comment.php?action=editcomment&c={$comment_id}");
        $pending = "<p>审核地址：<a href='{$comment_approve_url}'>{$comment_approve_url}</a></p>";
        $subject = "您的网站 [{$site_name}] 有了新的评论（待审核）";
      } else {
        $pending = '';
        $subject = "您的网站 [{$site_name}] 有了新的评论";
      }

      // 发给博主
      if ($post_type == 'post' || $post_type == 'page') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
          {$pending}
        ";
      } else if ($post_type == 'moment') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在片刻中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      } else {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      }
      wp_mail($admin_email, $subject, $message, $headers);
      return;
    }

    // 如果发送者不是博主，被回复者也不是博主
    if ($comment_author_email != $admin_email && $parent_comment_author_email != $admin_email) {
      // 发给被回复者和博主（xxx回复xxx）
      // 发给被回复者
      $subject = "您在网站 [{$site_name}] 中的评论有了新的回复";
      if ($post_type == 'post' || $post_type == 'page') {
        $message = "
          <p><b>{$parent_comment_author}</b>，您好！</p>
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
        ";
      } else if ($post_type == 'moment') {
        $message = "
          <p><b>{$parent_comment_author}</b>，您好！</p>
          <p>用户 <b>{$comment_author}</b> 在片刻中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
        ";
      } else {
        $message = "
          <p><b>{$parent_comment_author}</b>，您好！</p>
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
        ";
      }
      wp_mail($parent_comment_author_email, $subject, $message, $headers);

      // 发给博主
      $subject = "您的网站 [{$site_name}] 有了新的评论回复";
      if ($post_type == 'post' || $post_type == 'page') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>{$parent_comment_author}</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
        ";
      } else if ($post_type == 'moment') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在片刻中回复了 <b>{$parent_comment_author}</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
        ";
      } else {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中回复了 <b>{$parent_comment_author}</b> ：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
        ";
      }
      wp_mail($admin_email, $subject, $message, $headers);
      return;
    }

  } else {
    // 如果是博主的评论，则不发送邮件
    if ($comment_author_email == $admin_email) {
      return;
    }

    // 如果评论者不是博主，则发送邮件给博主
    if($comment_author_email != $admin_email) {
      // 如果是待批准状态
      if ($comment_status != 'approved') {
        $comment_approve_url = admin_url("comment.php?action=editcomment&c={$comment_id}");
        $pending = "<p>审核地址：<a href='{$comment_approve_url}'>{$comment_approve_url}</a></p>";
        $subject = "您的网站 [{$site_name}] 有了新的评论（待审核）";
      } else {
        $pending = '';
        $subject = "您的网站 [{$site_name}] 有了新的评论";
      }

      // 发给博主
      if ($post_type == 'post' || $post_type == 'page') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中发表了评论：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
          {$pending}
        ";
      } else if ($post_type == 'moment') {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在片刻中发表了评论：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      } else {
        $message = "
          <p>用户 <b>{$comment_author}</b> 在文章 <b>{$post_name}</b> 中发表了评论：</p>
          <p {$email_css}>{$comment_content}</p>
          <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
          {$pending}
        ";
      }
      wp_mail($admin_email, $subject, $message, $headers);
      return;
    }
  }
}


// 审批通知
add_action('wp_set_comment_status', 'oyiso_comment_status_change', 10, 2);
function oyiso_comment_status_change($comment_id, $comment_status) {

  // 移至回收站或标记为垃圾评论时不发送邮件
  if (in_array($comment_status, ['trash', 'spam', 0, 1])) {
    return;
  }
  
  $comment = get_comment($comment_id); // 评论对象
  // 检查评论对象是否存在
  if (!$comment) {
    return;
  }
  $comment_author_email = $comment->comment_author_email; // 评论者邮箱
  $parent_comment_id = $comment->comment_parent; // 父级评论 ID
  $admin_email = get_option('admin_email'); // 博主邮箱

  $theme_colors = get_option('oyiso_theme_colors');
  if (isset($theme_colors->pri) && !empty($theme_colors->pri)) {
    $theme_color_pri = $theme_colors->pri;
  } else {
    $theme_color_pri = '#8183ff';
  }

  $email_css = "style='background-color:#f5f5f5;padding:15px;border-left:3px solid {$theme_color_pri};'"; // 邮件样式
  $headers = array('Content-Type: text/html; charset=UTF-8'); // 邮件头部


  // 通知回复者 -通过
  function reply($comment_id, $email_css, $headers, $success = true) {
    $comment = get_comment($comment_id); // 评论对象
    $comment_content = $comment->comment_content; // 评论内容
    $comment_author = $comment->comment_author; // 评论者昵称
    $comment_author_email = $comment->comment_author_email; // 评论者邮箱
    $smtp_sitename = get_option('oyiso_smtp_sitename'); // 自定义网站名称
    $site_name = $smtp_sitename ? $smtp_sitename : get_bloginfo('name'); // 网站名称
    $site_url = get_bloginfo('url'); // 网站链接
    $post_id = $comment->comment_post_ID; // 文章 ID
    $post_name = get_the_title($post_id); // 文章标题
    $post_url = get_permalink($post_id); // 文章链接
    $post_type = get_post_type($post_id); // 文章类型
    
    if ($success) {
      $status = '已通过审核';
    } else {
      $status = '已被驳回';
    }
    $subject = "您在网站 [{$site_name}] 中发表的评论{$status}！";
    if ($post_type == 'post' || $post_type == 'page') {
      if ($success) {
        $url = "<p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>";
      } else {
        $url = "<p>文章地址：<a href='{$post_url}'>{$post_url}</a></p>";
      }
      $message = "
        <p><b>{$comment_author}</b>，您好！</p>
        <p>您在文章 <b>{$post_name}</b> 中发表的评论{$status}！</p>
        <p>评论内容：</p>
        <p {$email_css}>{$comment_content}</p>
        {$url}
      ";
    } else if ($post_type == 'moment') {
      $message = "
        <p><b>{$comment_author}</b>，您好！</p>
        <p>您在片刻中发表的评论{$status}！</p>
        <p>评论内容：</p>
        <p {$email_css}>{$comment_content}</p>
        <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
      ";
    } else {
      $message = "
        <p><b>{$comment_author}</b>，您好！</p>
        <p>您在文章 <b>{$post_name}</b> 中发表的评论{$status}！</p>
        <p>评论内容：</p>
        <p {$email_css}>{$comment_content}</p>
        <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
      ";
    }
    wp_mail($comment_author_email, $subject, $message, $headers);
  }


  // 通知被回复者
  function reply_to($comment_id, $email_css, $headers, $parent_comment, $admin_email) {
    $comment = get_comment($comment_id); // 评论对象
    $comment_content = $comment->comment_content; // 评论内容
    $comment_author = $comment->comment_author; // 评论者昵称
    $comment_author_email = $comment->comment_author_email; // 评论者邮箱
    $smtp_sitename = get_option('oyiso_smtp_sitename'); // 自定义网站名称
    $site_name = $smtp_sitename ? $smtp_sitename : get_bloginfo('name'); // 网站名称
    $site_url = get_bloginfo('url'); // 网站链接
    $post_id = $comment->comment_post_ID; // 文章 ID
    $post_name = get_the_title($post_id); // 文章标题
    $post_url = get_permalink($post_id); // 文章链接
    $post_type = get_post_type($post_id); // 文章类型
    $parent_comment_author = $parent_comment->comment_author; // 被回复者昵称
    $parent_comment_author_email = $parent_comment->comment_author_email; // 被回复者邮箱
    
    if ($comment_author_email == $admin_email) {
      $reply_author = "博主 <b>{$comment_author}</b>";
    } else {
      $reply_author = "用户 <b>{$comment_author}</b>";
    }
    $subject = "您在网站 [{$site_name}] 中的评论有了新的回复！";
    if ($post_type == 'post' || $post_type == 'page') {
      $message = "
        <p><b>{$parent_comment_author}</b>，您好！</p>
        <p>{$reply_author} 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
        <p {$email_css}>{$comment_content}</p>
        <p>文章地址：<a href='{$post_url}#comment_reply={$comment_id}'>{$post_url}#comment_reply={$comment_id}</a></p>
      ";
    } else if ($post_type == 'moment') {
      $message = "
        <p><b>{$parent_comment_author}</b>，您好！</p>
        <p>{$reply_author} 在片刻中回复了 <b>您</b> ：</p>
        <p {$email_css}>{$comment_content}</p>
        <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
      ";
    } else {
      $message = "
        <p><b>{$parent_comment_author}</b>，您好！</p>
        <p>{$reply_author} 在文章 <b>{$post_name}</b> 中回复了 <b>您</b> ：</p>
        <p {$email_css}>{$comment_content}</p>
        <p>博客地址：<a href='{$site_url}'>{$site_url}</a></p>
      ";
    }
    wp_mail($parent_comment_author_email, $subject, $message, $headers);
  }

  // 如果是回复评论
  if (!empty($parent_comment_id)) {
    $parent_comment = get_comment($parent_comment_id); // 父级评论对象
    $parent_comment_author = $parent_comment->comment_author; // 被回复者昵称
    $parent_comment_author_email = $parent_comment->comment_author_email; // 被回复者邮箱

    // 如果回复者和被回复者是博主本人，则不发送邮件
    if ($parent_comment_author_email == $comment_author_email && $comment_author_email == $admin_email) {
      return;
    }

    // 如果回复者和被回复者是同一人，且不是博主，则发送邮件
    if ($parent_comment_author_email == $comment_author_email && $comment_author_email != $admin_email) {
      if ($comment_status == 'approve') {
        reply($comment_id, $email_css, $headers);
      } else {
        reply($comment_id, $email_css, $headers, false);
      }
      return;
    }

    // 如果回复者和被回复者不是同一个人，如果回复者是博主，被回复者是其他人
    if ($parent_comment_author_email != $comment_author_email && $comment_author_email == $admin_email && $parent_comment_author_email != $admin_email ) {
      if ($comment_status == 'approve') {
        reply_to($comment_id, $email_css,$headers, $parent_comment, $admin_email);
      }
      return;
    }
    
    // 如果回复者和被回复者不是同一个人，如果回复者是其他人，被回复者是博主
    if ($parent_comment_author_email != $comment_author_email && $comment_author_email != $admin_email && $parent_comment_author_email == $admin_email) {
      if ($comment_status == 'approve') {
        reply($comment_id, $email_css, $headers);
      } else {
        reply($comment_id, $email_css, $headers, false);
      }
      return;
    }

    if ($parent_comment_author_email != $comment_author_email && $comment_author_email != $admin_email && $parent_comment_author_email != $admin_email) {
      if ($comment_status == 'approve') {
        reply($comment_id, $email_css, $headers);
        reply_to($comment_id, $email_css,$headers, $parent_comment, $admin_email);
      } else {
        reply($comment_id, $email_css, $headers, false);
      }
      return;
    }

  } else {
    // 如果回复者博主本人，则不发送邮件
    if ($comment_author_email == $admin_email) {
      return;
    }

    // 如果回复者不是博主，则发送邮件
    if ($comment_status == 'approve') {
      reply($comment_id, $email_css, $headers);
    } else {
      reply($comment_id, $email_css, $headers, false);
    }
    return;
  }
}


// 关闭评论通知
add_filter('comments_notify', '__return_false');

// 关闭评论等待审核通知
add_filter('moderation_notify', '__return_false');